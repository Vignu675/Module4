package com.capg;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

public class JsDemo {

	public static void main(String[] args) {

		WebDriver driver = WebUtil.getWebDriver();

		//driver.get("C:\\test\\Bdd_Class_STS\\SeleniumWebDriver\\html\\DemoForJs.html");
		
		driver.get("https://en.wikipedia.org/wiki/India");

		JavascriptExecutor jse = (JavascriptExecutor) driver;
		
		//jse.executeScript("window.scrollBy(1000,2000)");
		jse.executeScript("window.scrollBy(0,document.body.scrollHeight)");
		
		// jse.executeScript("display();");

		//jse.executeScript("history.go(0)");
		
		//String str = jse.executeScript("return document.getElementById('h1').innerHTML").toString();
       // System.out.println(str);

	}

}
