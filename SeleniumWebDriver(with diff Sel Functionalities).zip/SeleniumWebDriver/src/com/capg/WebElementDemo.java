package com.capg;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class WebElementDemo {

	public static void main(String[]args) {
		
		WebDriver driver = WebUtil.getWebDriver();
			driver.navigate().to("https://www.toolsqa.com/automation-practice-form/");
		
		
		WebElement ele1 = driver.findElement(By.partialLinkText("SELENIUM"));
			ele1.click();
			driver.navigate().back();
			
		/*WebElement ele2 = driver.findElement(By.linkText("ABOUT"));
			ele2.click();
		
		WebElement gender = driver.findElement(By.id("sex-0"));
			gender.click();*/
			
			
			/*WebElement continent=driver.findElement(By.name("continents"));		//select by Index in drop down
			Select select=new Select(continent);
			select.selectByIndex(1);*/
			
			/*WebElement continent1=driver.findElement(By.name("continents"));		//select by value 
			Select select1=new Select(continent1);
			select1.selectByValue("AF");
			*/
			
			/*WebElement continent2=driver.findElement(By.name("continents"));		//select by visible name
			Select select2=new Select(continent2);
			select2.selectByVisibleText("Africa");*/
			
			
			WebElement dropdown = driver.findElement(By.xpath("//*[@id=\"continentsmultiple\"]"));
			Select select3 = new Select(dropdown);					//Select by Xpath
			select3.selectByVisibleText("Europe");
			
			
			/*WebElement dropdown1=driver.findElement(By.xpath("//select[@name=\"continents\"]"));
            Select select4=new Select(dropdown1);
            select4.selectByIndex(2);*/
			
				
		
	}
}
