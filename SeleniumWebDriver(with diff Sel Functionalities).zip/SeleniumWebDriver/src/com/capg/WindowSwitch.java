package com.capg;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class WindowSwitch {

	public static void main(String[] args) {

		WebDriver driver = WebUtil.getWebDriver();
		driver.get("C:\\test\\Bdd_Class_STS\\SeleniumWebDriver\\html\\PopupWin.html");

		String parentWindow = driver.getWindowHandle();
		driver.findElement(By.name("Open")).click();

		driver.switchTo().window("PopupWindow");
		//driver.close();
		driver.findElement(By.name("txtName")).sendKeys("Vignu");
        driver.findElement(By.name("btnAlert")).click();
        driver.switchTo().alert().accept();
		driver.switchTo().window(parentWindow);

	}

}
