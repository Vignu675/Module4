package com.capg;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class AlertDemo {

	public static void main(String[] args) {

		WebDriver driver = WebUtil.getWebDriver();
		driver.get("C:\\test\\Bdd_Class_STS\\SeleniumWebDriver\\html\\AlertExample.html");

		WebElement element = driver.findElement(By.name("btnAlert"));
		element.click();

		String alertText = driver.switchTo().alert().getText();
		System.out.println(alertText);
		//driver.switchTo().alert().accept();
		//driver.switchTo().alert().dismiss();

	}

}
