package com.capg.PomRepository;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class RegistrationPomRepository {

	@FindBy(id = "txtFullName")
	@CacheLookup
	WebElement fullName;

	@FindBy(id = "txtEmail")
	@CacheLookup
	WebElement email;

	@FindBy(id = "txtPhone")
	@CacheLookup
	WebElement mobileNo;

	@FindBy(id = "gender")
	@CacheLookup
	WebElement gender;

	@FindBy(how = How.NAME, using = "city")
	@CacheLookup
	WebElement city;

	@FindBy(how = How.NAME, using = "state")
	@CacheLookup
	WebElement state;

	@FindBy(id = "txtCardholderName")
	@CacheLookup
	WebElement subjectCategory;

	@FindBy(id = "txtDebit")
	@CacheLookup
	WebElement paperName;

	@FindBy(xpath = "//*[@id=\"txtCvv\"]")
	@CacheLookup
	WebElement noOfAuthors;

	@FindBy(id = "txtMonth")
	@CacheLookup
	WebElement companyName;

	@FindBy(id = "txtYear")
	@CacheLookup
	WebElement designation;

	@FindBy(id = "btnPayment")
	@CacheLookup
	WebElement confirmButton;

	WebDriver driver;

	public RegistrationPomRepository(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public WebElement getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName.sendKeys(fullName);
	}

	public WebElement getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public WebElement getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo.sendKeys(mobileNo);
	}

	public WebElement getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender.click();
	}

	public WebElement getCity() {
		return city;
	}

	public void setCity(String city) {

		this.city.sendKeys(city);

	}

	public WebElement getState() {
		return state;
	}

	public void setState(String state) {
		this.state.sendKeys(state);
	}

	public WebElement getSubjectCategory() {
		return subjectCategory;
	}

	public void setSubjectCategory(String subjectCategory) {
		this.subjectCategory.sendKeys(subjectCategory);
	}

	public WebElement getPaperName() {
		return paperName;
	}

	public void setPaperName(String paperName) {
		this.paperName.sendKeys(paperName);
	}

	public WebElement getNoOfAuthors() {
		return noOfAuthors;
	}

	public void setNoOfAuthors(String noOfAuthors) {
		this.noOfAuthors.sendKeys(noOfAuthors);
	}

	public WebElement getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName.sendKeys(companyName);
	}

	public WebElement getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation.sendKeys(designation);
	}

	public WebElement getConfirmButton() {
		return confirmButton;
	}

	public void setConfirmButton() {
		this.confirmButton.click();
	}

}
