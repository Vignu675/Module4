package com.capg.stepdefinitions;

import org.junit.BeforeClass;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.capg.PomRepository.PomRepository;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PaperSubmissionStepDefinition {
	private WebDriver driver;
	private PomRepository pomRepo;

	/*
	 * public void setUp() { System.setProperty("webdriver.chrome.driver",
	 * "C:\\chromedriver\\chromedriver.exe");
	 * 
	 * this.driver = new ChromeDriver();
	 * 
	 * }
	 */

	public WebDriver getDriver() {

		System.setProperty("webdriver.chrome.driver", "C:\\chromedriver\\chromedriver.exe");

		System.out.println("1");

		WebDriver driver = new ChromeDriver();
		return driver;

	}

	@Given("^user is on 'paperSubmission' page$")
	public void user_is_on_paperSubmission_page() {

		driver = getDriver();

		driver.get("C:\\test\\Bdd_Class_STS\\ZPaperSubmission_Bdd\\htmlFiles\\login.html");
		pomRepo = new PomRepository(driver);
	}

	@When("^user enters invalid userName$")
	public void user_enters_invalid_userName() {
		pomRepo.setUserName("Vignesh");
		pomRepo.setPassword("vrl1234");
		pomRepo.setLoginButton();

	}

	@Then("^displays 'Please fill the valid userName or password'$")
	public void displays_Please_fill_the_valid_userName() {
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters invalid password$")
	public void user_enters_invalid_password() {
		pomRepo.setUserName("vrl");
		pomRepo.setPassword("vrl123");
		pomRepo.setLoginButton();
	}

	@When("^user enters valid details$")
	public void user_enters_valid_details() {
		pomRepo.setUserName("vrl");
		pomRepo.setPassword("vrl1234");
		pomRepo.setLoginButton();
	}

	@Then("^displays 'Login Successful'$")
	public void displays_Login_Successful() {
		driver.get("C:\\test\\Bdd_Class_STS\\ZPaperSubmission_Bdd\\htmlFiles\\registration.html");
	}

}
