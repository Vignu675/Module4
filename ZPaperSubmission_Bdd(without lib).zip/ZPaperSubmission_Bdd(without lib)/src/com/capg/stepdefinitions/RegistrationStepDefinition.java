package com.capg.stepdefinitions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import com.capg.PomRepository.RegistrationPomRepository;

import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RegistrationStepDefinition {

	private WebDriver driver;
	private RegistrationPomRepository registrationRepo;

	public WebDriver getDriver() {

		System.setProperty("webdriver.chrome.driver", "C:\\chromedriver\\chromedriver.exe");

		WebDriver driver = new ChromeDriver();
		return driver;

	}

	@Given("^user is on 'Paper Registration' page$")
	public void user_is_on_Paper_Registration_page() {

		driver = getDriver();
		registrationRepo = new RegistrationPomRepository(driver);
		driver.get("C:\\test\\Bdd_Class_STS\\ZPaperSubmission_Bdd\\htmlFiles\\registration.html");

	}

	@When("^user enters invalid first name$")
	public void user_enters_invalid_first_name() throws Throwable {
		registrationRepo.setFullName("");
		registrationRepo.setConfirmButton();
	}

	@Then("^displays 'Please fill the full Name'$")
	public void displays_Please_fill_the_full_Name() throws Throwable {

	}

	@When("^user enters invalid email$")
	public void user_enters_invalid_email() throws Throwable {
		registrationRepo.setFullName("Vignesh");
		registrationRepo.setEmail("abcd");
		registrationRepo.setConfirmButton();
	}

	@Then("^displays 'Please fill the email'$")
	public void displays_Please_fill_the_email() throws Throwable {

	}

	@When("^user enters invalid mobile number$")
	public void user_enters_invalid_mobile_number() throws Throwable {
		registrationRepo.setFullName("Vignesh");
		registrationRepo.setEmail("manikyavignesh.m@gmail.com");
		registrationRepo.setMobileNo("96401");
		registrationRepo.setConfirmButton();
	}

	@Then("^displays 'Please fill the mobile number'$")
	public void displays_Please_fill_the_mobile_number() throws Throwable {

	}

	@When("^user enters invalid Gender$")
	public void user_enters_invalid_Gender() throws Throwable {
		registrationRepo.setFullName("Vignesh");
		registrationRepo.setEmail("manikyavignesh.m@gmail.com");
		registrationRepo.setMobileNo("9640180675");
		registrationRepo.setGender("Male");
		registrationRepo.setConfirmButton();
	}

	@Then("^displays 'Please fill the Gender'$")
	public void displays_Please_fill_the_Gender() throws Throwable {

	}

	@When("^user enters invalid City$")
	public void user_enters_invalid_City() throws Throwable {
		registrationRepo.setFullName("Vignesh");
		registrationRepo.setEmail("manikyavignesh.m@gmail.com");
		registrationRepo.setMobileNo("9640180675");
		registrationRepo.setGender("Male");
		registrationRepo.setCity("Chennai");
		registrationRepo.setConfirmButton();
	}

	@Then("^displays 'Please fill the City'$")
	public void displays_Please_fill_the_City() throws Throwable {

	}

	@When("^user enters invalid State$")
	public void user_enters_invalid_State() throws Throwable {
		registrationRepo.setFullName("Vignesh");
		registrationRepo.setEmail("manikyavignesh.m@gmail.com");
		registrationRepo.setMobileNo("9640180675");
		registrationRepo.setGender("Male");
		registrationRepo.setCity("Chennai");
		registrationRepo.setState("Tamilnadu");
		registrationRepo.setConfirmButton();
	}

	@Then("^displays 'Please fill the State'$")
	public void displays_Please_fill_the_State() throws Throwable {

	}

	@When("^user enters invalid Subject Category$")
	public void user_enters_invalid_Subject_Category() throws Throwable {
		registrationRepo.setFullName("Vignesh");
		registrationRepo.setEmail("manikyavignesh.m@gmail.com");
		registrationRepo.setMobileNo("9640180675");
		registrationRepo.setGender("Male");
		registrationRepo.setCity("Chennai");
		registrationRepo.setState("Tamilnadu");
		registrationRepo.setSubjectCategory("");
		registrationRepo.setConfirmButton();
	}

	@Then("^displays 'Please fill the Subject Category'$")
	public void displays_Please_fill_the_Subject_Category() throws Throwable {

	}

	@When("^user enters invalid Paper Name$")
	public void user_enters_invalid_Paper_Name() throws Throwable {
		registrationRepo.setFullName("Vignesh");
		registrationRepo.setEmail("manikyavignesh.m@gmail.com");
		registrationRepo.setMobileNo("9640180675");
		registrationRepo.setGender("Male");
		registrationRepo.setCity("Chennai");
		registrationRepo.setState("Tamilnadu");
		registrationRepo.setSubjectCategory("Bdd");
		registrationRepo.setPaperName("");
		registrationRepo.setConfirmButton();
	}

	@Then("^displays 'Please fill the Paper Name'$")
	public void displays_Please_fill_the_Paper_Name() throws Throwable {

	}

	@When("^user enters invalid Author Number$")
	public void user_enters_invalid_Author_Number() throws Throwable {
		registrationRepo.setFullName("Vignesh");
		registrationRepo.setEmail("manikyavignesh.m@gmail.com");
		registrationRepo.setMobileNo("9640180675");
		registrationRepo.setGender("Male");
		registrationRepo.setCity("Chennai");
		registrationRepo.setState("Tamilnadu");
		registrationRepo.setSubjectCategory("Bdd");
		registrationRepo.setPaperName("BddTesting");
		registrationRepo.setNoOfAuthors("");
		registrationRepo.setConfirmButton();
	}

	@Then("^displays 'Please fill the Author Number'$")
	public void displays_Please_fill_the_Author_Number() throws Throwable {

	}

	@When("^user enters invalid Company Name$")
	public void user_enters_invalid_Company_Name() throws Throwable {
		registrationRepo.setFullName("Vignesh");
		registrationRepo.setEmail("manikyavignesh.m@gmail.com");
		registrationRepo.setMobileNo("9640180675");
		registrationRepo.setGender("Male");
		registrationRepo.setCity("Chennai");
		registrationRepo.setState("Tamilnadu");
		registrationRepo.setSubjectCategory("Bdd");
		registrationRepo.setPaperName("BddTesting");
		registrationRepo.setNoOfAuthors("1");
		registrationRepo.setCompanyName("");
		registrationRepo.setConfirmButton();
	}

	@Then("^displays 'Please fill the Company Name'$")
	public void displays_Please_fill_the_Company_Name() throws Throwable {

	}

	@When("^user enters invalid Designation$")
	public void user_enters_invalid_Designation() throws Throwable {
		registrationRepo.setFullName("Vignesh");
		registrationRepo.setEmail("manikyavignesh.m@gmail.com");
		registrationRepo.setMobileNo("9640180675");
		registrationRepo.setGender("Male");
		registrationRepo.setCity("Chennai");
		registrationRepo.setState("Tamilnadu");
		registrationRepo.setSubjectCategory("Bdd");
		registrationRepo.setPaperName("BddTesting");
		registrationRepo.setNoOfAuthors("3");
		registrationRepo.setCompanyName("Capgemini");
		registrationRepo.setDesignation("");
		registrationRepo.setConfirmButton();
	}

	@Then("^displays 'Please fill the Designation'$")
	public void displays_Please_fill_the_Designation() throws Throwable {

	}

	@When("^user enters valid Registration Details$")
	public void user_enters_valid_Registration_Details() throws Throwable {
		registrationRepo.setFullName("Vignesh");
		registrationRepo.setEmail("manikyavignesh.m@gmail.com");
		registrationRepo.setMobileNo("9640180675");
		registrationRepo.setGender("Male");
		registrationRepo.setCity("Chennai");
		registrationRepo.setState("Tamilnadu");
		registrationRepo.setSubjectCategory("Bdd");
		registrationRepo.setPaperName("BddTesting");
		registrationRepo.setNoOfAuthors("3");
		registrationRepo.setCompanyName("Capgemini");
		registrationRepo.setDesignation("Jee");
	}

	@Then("^displays 'Success Page'$")
	public void displays_Success_Page() throws Throwable {
		
		registrationRepo.setConfirmButton();

		/*WebElement registration = registrationRepo.getConfirmButton();
		registration.click();*/
	}

}
