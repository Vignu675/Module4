package com.capg.stepdefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepsDefinition {
	WebDriver driver;

	@Given("^Open browser and enter icompass url$")
	public void open_browser_and_enter_icompass_url() throws Throwable {

		String path = "C:\\chromedriver\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", path);

		driver = new ChromeDriver();

		String url = "https://icompassweb.fs.capgemini.com";
		driver.get(url);

	}

	@When("^user enters valid user-name \"([^\"]*)\" and valid password \"([^\"]*)\"$")
	public void user_enters_valid_user_name_and_valid_password(String username, String password) throws Throwable {

		WebElement userTextField = driver.findElement(By.id("userName"));
		WebElement passwordTextField = driver.findElement(By.id("password"));

		userTextField.sendKeys(username);
		passwordTextField.sendKeys(password);

	}

	@Then("^Login successfully and display icompass page$")
	public void login_successfully_and_display_icompass_page() throws Throwable {

		WebElement loginButton = driver.findElement(By.id("loginButton"));
		loginButton.click();
		
		
	}

}
