package com.capg.stepdefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class stepsdefinition {

	WebDriver driver;
	
	@Given("^Open browser and enter flipkart url$")
	public void open_browser_and_enter_flipkart_url(){
	    
		String path = "C:\\chromedriver\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", path);
		
		driver = new ChromeDriver();
		
		String url = "https://www.flipkart.com";
		driver.get(url);
		
	}

	@When("^User enters mobile number \"([^\"]*)\"$")
	public void user_enters_mobile_number(String number){
		
		//WebElement mobileNoElement = driver.findElement(By.className("_2zrpKA _1dBPDZ"));
		WebElement mobileNoElement = driver.findElement(By.className("_2zrpKA"));
		mobileNoElement.sendKeys(number);
		
	}

	@Then("^send OTP by clicking the SendOTP button$")
	public void send_OTP_by_clicking_the_SendOTP_button(){
	    
		WebElement sendOtpButton = driver.findElement(By.className("jUwFiZ"));
		sendOtpButton.click();
		//class="_2AkmmA _1LctnI jUwFiZ"
		
	}

}
