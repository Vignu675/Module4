package com.capg.pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class PageObjRepo {

	@FindBy(id = "userName")
	@CacheLookup
	WebElement userField;

	@FindBy(how = How.ID, using = "password")
	@CacheLookup
	WebElement passwordField;

	@FindBy(id = "loginButton")
	@CacheLookup
	WebElement lognButton;

	public PageObjRepo(WebDriver driver){
		
		PageFactory.initElements(driver, this);
		
	}
	
	
	
	public WebElement getUserField() {
		return userField;
	}

	public void setUserField(WebElement userField) {
		this.userField = userField;
	}

	public WebElement getPasswordField() {
		return passwordField;
	}

	public void setPasswordField(WebElement passwordField) {
		this.passwordField = passwordField;
	}

	public WebElement getLognButton() {
		return lognButton;
	}

	public void setLognButton(WebElement lognButton) {
		this.lognButton = lognButton;
	}

}
