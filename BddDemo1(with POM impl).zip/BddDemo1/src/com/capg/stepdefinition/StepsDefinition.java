package com.capg.stepdefinition;

import org.openqa.selenium.WebDriver;

import com.capg.pom.WebPOM;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepsDefinition {
	WebDriver driver;

	@Given("^Open browser and enter icompass url$")
	public void open_browser_and_enter_icompass_url() throws Throwable {

		driver = WebPOM.getWebDriver();

		String url = "https://icompassweb.fs.capgemini.com";
		driver.get(url);

	}

	@When("^user enters valid user-name \"([^\"]*)\" and valid password \"([^\"]*)\"$")
	public void user_enters_valid_user_name_and_valid_password(String username, String password) throws Throwable {

		WebPOM.getUserField().sendKeys(username);
		WebPOM.getPasswordField().sendKeys(password);

	}

	@Then("^Login successfully and display icompass page$")
	public void login_successfully_and_display_icompass_page() throws Throwable {

		WebPOM.getLoginButton().click();

	}

}
