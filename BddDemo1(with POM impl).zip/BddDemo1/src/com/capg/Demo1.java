package com.capg;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Demo1 {

	public static void main(String[] args) {

		// Step1---Open the Browser

		String path = "C:\\chromedriver\\chromedriver.exe";

		System.setProperty("webdriver.chrome.driver", path);

		WebDriver driver = new ChromeDriver();

		//

		driver.get("http:\\www.google.com");

		// Sending value to text element
		WebElement element = driver.findElement(By.name("q"));
		element.sendKeys("Chennai Climate");
		element.sendKeys("\n");

		//WebElement element1 = driver.findElement(By.className("sbl1"));
		

	}

}
