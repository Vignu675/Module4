package com.capg.stepdefinition;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.capg.WebUtil;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepsDefinitions {

	WebDriver driver;
	
	@Given("^Navigate to Icompass URL to display login page$")
	public void navigate_to_Icompass_URL_to_display_login_page() throws Throwable {
	 
		driver = WebUtil.getWebDriver();
		 
		String url = "https://icompassweb.fs.capgemini.com";
		driver.get(url);
	}

	/*@When("^user enter login credentials \"([^\"]*)\" and password \"([^\"]*)\"$")
	public void user_enter_login_credentials_and_password(String username, String password) throws Throwable {
	   
		WebElement userText = driver.findElement(By.id("userName"));
		WebElement passwordText = driver.findElement(By.id("password"));
		
			userText.sendKeys(username);
			passwordText.sendKeys(password);
		
	}*/
	
	
	@When("^user enter login credentials$")
	public void user_enter_login_credentials(DataTable data) {
	    
		List<List<String>> table = data.raw();
		
		WebElement userText = driver.findElement(By.id("userName"));
		WebElement passwordText = driver.findElement(By.id("password"));
		
		String username = table.get(0).get(0);
		String password = table.get(0).get(1);
		
		userText.sendKeys(username);
		passwordText.sendKeys(password);
	}


	@Then("^validation should be performed$")
	public void validation_should_be_performed() throws Throwable {
	   
		WebElement login = driver.findElement(By.id("loginButton"));
		login.click();
		
		
	}

	
}
