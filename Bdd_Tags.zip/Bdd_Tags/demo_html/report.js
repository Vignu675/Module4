$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("src/login.feature");
formatter.feature({
  "line": 2,
  "name": "Multiple Scenario Testing",
  "description": "",
  "id": "multiple-scenario-testing",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@AllInOne"
    }
  ]
});
formatter.scenario({
  "comments": [
    {
      "line": 4,
      "value": "#@FasterFingersFirst"
    }
  ],
  "line": 5,
  "name": "Login Icompass with valid credentials",
  "description": "",
  "id": "multiple-scenario-testing;login-icompass-with-valid-credentials",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 7,
  "name": "Navigate to Icompass through a browser",
  "keyword": "Given "
});
formatter.step({
  "line": 9,
  "name": "User credentials are valid username \"190122\" and password \"Love*Care\"",
  "keyword": "When "
});
formatter.step({
  "line": 11,
  "name": "Login Successfully",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinitions.navigate_to_Icompass_through_a_browser()"
});
formatter.result({
  "duration": 8873989900,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "190122",
      "offset": 37
    },
    {
      "val": "Love*Care",
      "offset": 59
    }
  ],
  "location": "StepDefinitions.user_credentials_are_valid_username_and_password(String,String)"
});
formatter.result({
  "duration": 190118100,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinitions.login_Successfully()"
});
formatter.result({
  "duration": 226047600,
  "status": "passed"
});
formatter.scenario({
  "comments": [
    {
      "line": 13,
      "value": "#@SecondWife"
    }
  ],
  "line": 14,
  "name": "Displaying Climate Updates",
  "description": "",
  "id": "multiple-scenario-testing;displaying-climate-updates",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 16,
  "name": "Navigate through Google url",
  "keyword": "Given "
});
formatter.step({
  "line": 18,
  "name": "User enter input \"Chennai Climate\"",
  "keyword": "When "
});
formatter.step({
  "line": 20,
  "name": "Climate details displayed",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinitions.navigate_through_Google_url()"
});
formatter.result({
  "duration": 5768455200,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Chennai Climate",
      "offset": 18
    }
  ],
  "location": "StepDefinitions.user_enter_input(String)"
});
formatter.result({
  "duration": 3892925000,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinitions.climate_details_displayed()"
});
formatter.result({
  "duration": 2319760800,
  "status": "passed"
});
formatter.scenario({
  "line": 23,
  "name": "Displaying Google images",
  "description": "",
  "id": "multiple-scenario-testing;displaying-google-images",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 25,
  "name": "Navigate through Google url",
  "keyword": "Given "
});
formatter.step({
  "line": 27,
  "name": "User click on image link",
  "keyword": "When "
});
formatter.step({
  "line": 29,
  "name": "Display images page",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinitions.navigate_through_Google_url()"
});
formatter.result({
  "duration": 5500792400,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinitions.user_click_on_image_link()"
});
formatter.result({
  "duration": 764841500,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinitions.display_images_page()"
});
formatter.result({
  "duration": 16700,
  "status": "passed"
});
});