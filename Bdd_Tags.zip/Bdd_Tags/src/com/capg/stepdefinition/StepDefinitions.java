package com.capg.stepdefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.capg.WebUtil;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefinitions {
	WebDriver driver;

	@Given("^Navigate to Icompass through a browser$")
	public void navigate_to_Icompass_through_a_browser() throws Throwable {

		driver = WebUtil.getWebDriver();
		String url = "https://icompassweb.fs.capgemini.com";
		driver.get(url);

	}

	@When("^User credentials are valid username \"([^\"]*)\" and password \"([^\"]*)\"$")
	public void user_credentials_are_valid_username_and_password(String username, String password) throws Throwable {

		WebElement userTextField = driver.findElement(By.id("userName"));
		WebElement passwordTextField = driver.findElement(By.id("password"));

		userTextField.sendKeys(username);
		passwordTextField.sendKeys(password);

	}

	@Then("^Login Successfully$")
	public void login_Successfully() throws Throwable {

		WebElement loginButton = driver.findElement(By.id("loginButton"));
		loginButton.click();
		driver.close();
	}

	@Given("^Navigate through Google url$")
	public void navigate_through_Google_url() throws Throwable {

		driver = WebUtil.getWebDriver();
		String url = "https://www.google.com";
		driver.navigate().to(url); // driver.get()
	}

	@When("^User enter input \"([^\"]*)\"$")
	public void user_enter_input(String input) throws Throwable {

		WebElement searchField = driver.findElement(By.name("q"));
		searchField.sendKeys(input);
		searchField.sendKeys("\n");

	}

	@Then("^Climate details displayed$")
	public void climate_details_displayed() throws Throwable {

		driver.close();
	}

	@When("^User click on image link$")
	public void user_click_on_image_link() throws Throwable {

		WebElement imageLink = driver.findElement(By.className("gb_e"));
		imageLink.click();

	}

	@Then("^Display images page$")
	public void display_images_page() throws Throwable {

	}

}
